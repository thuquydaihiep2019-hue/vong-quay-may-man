import React, { useState } from 'react';

const studentsKey = 'vongquay_students';
const scoresKey = 'vongquay_scores';

function App() {
  const [students, setStudents] = useState(() => {
    const saved = localStorage.getItem(studentsKey);
    return saved ? JSON.parse(saved) : [];
  });
  const [currentStudent, setCurrentStudent] = useState('');
  const [scores, setScores] = useState(() => {
    const saved = localStorage.getItem(scoresKey);
    return saved ? JSON.parse(saved) : {};
  });
  const [result, setResult] = useState('');

  const wheelItems = [
    'Cộng', 'Trừ', 'Nhân', 'Chia',
    'May mắn +2 điểm', 'Mất lượt',
    'Câu hỏi lời văn', 'Ô trống'
  ];

  const spinWheel = () => {
    const random = Math.floor(Math.random() * wheelItems.length);
    const outcome = wheelItems[random];
    setResult(outcome);

    if (!currentStudent) return;
    let today = new Date().toISOString().split('T')[0];
    const newScores = { ...scores };
    if (!newScores[today]) newScores[today] = {};
    if (!newScores[today][currentStudent]) newScores[today][currentStudent] = 0;

    if (outcome.includes('May mắn')) {
      newScores[today][currentStudent] += 2;
    } else if (['Cộng','Trừ','Nhân','Chia','Câu hỏi lời văn'].includes(outcome)) {
      newScores[today][currentStudent] += 1;
    }
    setScores(newScores);
    localStorage.setItem(scoresKey, JSON.stringify(newScores));
  };

  const addStudent = () => {
    if (currentStudent && !students.includes(currentStudent)) {
      const newStudents = [...students, currentStudent];
      setStudents(newStudents);
      localStorage.setItem(studentsKey, JSON.stringify(newStudents));
    }
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>🎡 Vòng quay may mắn - Toán lớp 3</h1>

      <div>
        <input
          type="text"
          placeholder="Tên học sinh"
          value={currentStudent}
          onChange={(e) => setCurrentStudent(e.target.value)}
        />
        <button onClick={addStudent}>Thêm học sinh</button>
      </div>

      <div style={{ marginTop: 10 }}>
        <button onClick={spinWheel}>Quay vòng</button>
      </div>

      {result && (
        <h2>Kết quả: {result}</h2>
      )}

      <h3>📊 Bảng điểm hôm nay</h3>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Học sinh</th>
            <th>Điểm</th>
          </tr>
        </thead>
        <tbody>
          {students.map(s => (
            <tr key={s}>
              <td>{s}</td>
              <td>{(scores[new Date().toISOString().split('T')[0]] || {})[s] || 0}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
